import './App.css';
function Ink (){
    return (
        <div className="ink">
            <div>
            <img className='img-ink' src='https://www.lipla.ru/wp-content/uploads/2021/08/homepage-slide-3.png' alt='lipla'></img>
            </div>
     
        <h2>УФ/LED-отверждаемые чернила премиум класса</h2>
        <h3>Универсальные чернила для широкоформатной печати.</h3>
        <p>Применение на широком спектре оборудования: VUTEK, Oce Arizona, DYSS, HandTop, Matan, Magellan, Durst, Flora, BigPrinter, Sprinter, HP, HandTop, Mimaki...</p>
        <h3>ЧЕРНИЛА  УНИВЕРСАЛЬНЫ ДЛЯ ПЕЧАТНЫХ ГОЛОВ.</h3>
        <p>Совместимость с распространенными печатными головками таких производителей, как RICOH (в том числе последнее поколение GEN6-MH5320/5340), Konica Minolta, Kyocera, SPECTRA, Toshiba, XAAR...</p>
        <h3>УНИВЕРСАЛЬНЫ
ДЛЯ ПРОИЗВОДИМОЙ ПРОДУКЦИИ.
</h3>
<p>Возможность печатать на различных поверхностях, использование в интерьерной печати: на стекле, акриле, дверях и мебели, офисных перегородках, скинали.</p>

      </div>
    )
    }
    
    export default Ink;